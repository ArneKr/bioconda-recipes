#ifndef R_STUFF_H
#define R_STUFF_H

void print_autocorr_plot(char *fname, int *h, double *R, int length);
/* Output R script to print an autocorrelation plot */

#endif
