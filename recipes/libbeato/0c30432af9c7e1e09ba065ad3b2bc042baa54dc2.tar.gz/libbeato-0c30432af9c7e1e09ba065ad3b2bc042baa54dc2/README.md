[![Build Status](https://travis-ci.org/CRG-Barcelona/libbeato.svg?branch=master)](https://travis-ci.org/CRG-Barcelona/libbeato)
## libbeato
This is a C library containing routines for various uses in Genomics, and includes a copy of the freeware portion of the C library from UCSC's Genome Browser Group.  
